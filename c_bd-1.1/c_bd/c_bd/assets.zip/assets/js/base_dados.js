import * as defs from './datatable_conf.js';

function devolve_configuracoes_colunas($tabela, $var_configuracao){
    let info_final = []
    let colunas_thead_tr_ultimo = $('thead tr:last th', $tabela);
    $.each(colunas_thead_tr_ultimo, function() {
        info_final.push({
            data : $(this).data('cbdcamp').split(" ")[0],
            name : $(this).data('cbdcamp').split(" ")[0],
            orderable : $(this).data('cbdorde'),
            searchable : $(this).data('cbdproc'),
            visible : $(this).data('cbdapre'),
            width : $(this).data('cbdtama')
        })
    })

    return $var_configuracao = {...$var_configuracao,...{columns : info_final}}
}

$(document).ready(function(){
    moment.locale('pt')

    INFOS_DATATABLE = JSON.parse(INFOS_DATATABLE)

    // Transformar | em '

    $.each(INFOS_DATATABLE['columns'], function() {
        if (this["defaultContent"]) {
            this["defaultContent"] = this["defaultContent"].replaceAll("|", "'")
        }
        // scrollY: $(window).height() - $("#tblUtils").position().top - 130,
    });

    if (INFOS_DATATABLE['caption'] != undefined)
        INFOS_DATATABLE['caption'] = INFOS_DATATABLE['caption'].replaceAll("|", "'")

    let tbls = $(".tabela_c_bd").DataTable({...defs.CONF_DATATABLE, ...INFOS_DATATABLE})

    $(".tabela_c_bd tbody,.tabela_c_bd caption").on("click", ".tooltip-tabela", function() {
        if ($(this).data('href') != '#') {
            let linha = tbls.row($(this).parents('tr')).data()
            
            let passagem = ($(this).data("passagem") == undefined) ? ['?','&'] : (($(this).data("passagem").includes("url")) ? ['?','&'] : ['/','/'])

            let str_vars = $(this).data("vars").trim()
            let variaveis = passagem[0]

            if (str_vars.length > 0 && linha!=undefined) {
                let v = str_vars.split(",")

                $.each(v, function (idx, valor) {
                    variaveis += (variaveis[variaveis.length-1] != passagem[0] && variaveis[variaveis.length-1] != passagem[1]) ? passagem[1] : ""

                    if (linha[valor.trim()] != undefined)
                        if (passagem[0] == "?")
                            variaveis += valor.trim() + "=" + linha[valor.trim()]
                        else
                            variaveis += linha[valor.trim()]
                })
            }

            variaveis = (variaveis.trim() == passagem[0]) ? "" : ((variaveis[variaveis.length-1] == passagem[1]) ? variaveis=variaveis.slice(0,-1) : variaveis)

            window.location.href = $(this).data("href") + variaveis;
        }
        else {
            // if ($(this).data("modal") != undefined) {
            //     if ($(this).data("vars") != undefined) {
            //         let str_vars = $(this).data("vars").trim().replaceAll(", ",",")
            //         $("#" + $(this).data("modal")).data("parametros", str_vars)
            //     }
            //     else
            //         $("#" + $(this).data("modal")).data("parametros", "")

            //     console.log("Abrir modal com o id: "+  $(this).data("modal"))

            //     $("#" + $(this).data("modal")).modal('show')
            // }
        }
    })

    Ativar_Tooltips()

    $(".tabela_c_bd tbody").on("click", ".tooltip-tabela", function() {
        if ($(this).hasClass("btnImprimir")) {
            $("#mdlErroGeral .modal-texto").html("Teste de erro!!!")
            $("#mdlErroGeral").modal('show')
        }
    })
})