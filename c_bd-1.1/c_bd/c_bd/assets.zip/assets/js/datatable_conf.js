export const CONF_DATATABLE = {
    "language": {
        "url": '/static/c_bd/DataTables/pt-PT.json'
    },
    scrollCollapse: true,
    scrollX: true,
    scrollY: 500,
    responsive: false,
    // columnDefs: [
    //     {
    //         targets: -1,
    //         createdCell : function (td, cellData, rowData, row, col) {
    //             alert(JSON.stringify(cellData))
    //             // if (cellData < 1) {
    //             //     $(td).css('color', 'red');
    //             // }
    //         }
    //     }
    // ],
    dom: "<'row align-items-center bg-info py-1 bg-opacity-25 m-1 border border-2 border-secondary'<'col-9'i><'col-3'f>><'row'<'col-12'tr>>", //    "<'row'<'col-sm-12'p>>",
    "drawCallback": function () {
        $(".tooltip-tabela").tooltip({
            containeer: 'body',
            placement: 'top', customClass: 'custom-tooltip',
            delay: {"show": 500, "hide": 0},
        })
    },
}
