function Ativar_Tooltips() {
    $(".tooltip-tabela").tooltip({
        containeer: 'body', 
        placement: 'top', customClass: 'custom-tooltip',
        delay: {"show": 500, "hide": 0},
    })
}

