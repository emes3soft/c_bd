import * as defs from './datatable_conf.js';

function devolve_configuracoes_colunas($tabela, $var_configuracao){
    let info_final = []
    let colunas_thead_tr_ultimo = $('thead tr:last th', $tabela);
    $.each(colunas_thead_tr_ultimo, function() {
        info_final.push({
            data : $(this).data('cbdcamp').split(" ")[0],
            name : $(this).data('cbdcamp').split(" ")[0],
            orderable : $(this).data('cbdorde'),
            searchable : $(this).data('cbdproc'),
            visible : $(this).data('cbdapre'),
            width : $(this).data('cbdtama')
        })
    })

    return $var_configuracao = {...$var_configuracao,...{columns : info_final}}
}

$(document).ready(function(){
    moment.locale('pt')

    let tabelas = $(".tabela_c_bd")
    
    // alert(JSON.stringify(devolve_configuracoes_colunas(tabelas[0], defs.CONF_DATATABLE)))

    let tbls = $(".tabela_c_bd").DataTable(devolve_configuracoes_colunas(tabelas[0], defs.CONF_DATATABLE))

    Ativar_Tooltips()
})