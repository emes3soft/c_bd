
function Limpar_Textos_Erros(Formulario, reset_formulario = true)
{
    let elementos = Formulario.find('input,textarea,select').filter(':enabled:visible');

    elementos.each(function() {
        validar_caixa_erro("#" + $(this).attr("id"), 0);
    });	
    
    if (reset_formulario)
        Formulario.trigger('reset');
    else
        Formulario.limpar_espacos();
}

$(document).ready(function () {
    $(document).on('shown.bs.modal', '.modal', function () {
        $(this).find('input[type=text],input[type=password],textarea,select').filter(':enabled:visible:first').focus();	
        $(this).find('input[type=text],input[type=password],textarea,select').each(function () {
            $(this).attr('autocomplete','off');
        })
    });
    
    $(document).on('hide.bs.modal', '.modal', function () {
        Limpar_Textos_Erros($(this).find("form"));
    });
    
    $('input,textarea').on('focus', function () {
        $(this).select();
    });

    $("input[type=text],textarea").on("focusout", function(e) {
        $(this).val($(this).val().trim());
    });
    
    function fechar_modal(object, reset_form = true) {
        if (reset_form)
        {
            formID = object.parents('form').attr('id');
            $("#" + formID).trigger("reset");    
        }
        modalID = object.attr('data-target');
        $("#" + modalID).modal("hide");
    }

    $('button[type="reset"]').click(function() {

    });

    $('button[type="submit"]').click(function() {

    });
})