
function ficheiro_existe(ficheiro){
    return $.ajax({
        url: ficheiro,
        type:'HEAD',
        error: function()
        {
            return false;
        },
        success: function()
        {
            return true;
        }
    });
}

function x_tamanho_tabela(nome_tabela) {
    return $(window).width() - $("#" + nome_tabela).position().left - 10;
}

function y_tamanho_tabela(nome_tabela) {
    return $(window).height() - $("#" + nome_tabela).position().top - 160;
}

//função para input os inputs de numeros
// false - Número sem parte decimal, true - Número com parte decimal
function So_Numeros(event, numero_dec = false) {
    var key = window.event ? event.keyCode : event.which;

    if (numero_dec)
        if ($(this).val().indexOf(',') != -1)
        numero_dec = false;
    
    //         basckspace               tab                  ,                                         return                         
    if (event.keyCode === 8 || event.keyCode === 9 || (event.keyCode === 44 && numero_dec) || event.keyCode === 13) {
        return true;
    } else if (key < 48 || key > 57) {
        return false;
    } else return true;
}

//função para input os inputs de numeros
function So_Codigo_Postal(event, formato = "0000-000") {
    let key = window.event ? event.keyCode : event.which;
    let maxlen = formato.length;

    if ($(this).val().length >= maxlen)
        return false;
    
    let carater = formato[$(this).val().length];

    if (carater != 0 && event.keyCode !== 8)
        $(this).val($(this).val() + carater);

    else if (event.keyCode === 8 || event.keyCode === 9 || event.keyCode === 13) {
        return true;
    } 
    else if (key < 48 || key > 57) {
        return false;
    }
    else return true;
}

$(document).ready(function() {
    $('.numero').keypress(So_Numeros);
    $('.codigopostal').keypress(So_Codigo_Postal);

    $("input").on("focus", function(e) {
        $(this).select();
    });

    $("input.data_simples").attr("readonly","readonly");
})