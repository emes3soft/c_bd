// Translator for portuguese language
class cor {
    static get sucesso() { return sucess };
    static get erro() { return sucess };
    static get informacao() { return sucess };
    static get aviso() { return sucess };
    static get primario() { return sucess };
    static get secundario() { return sucess };
    static get escuro() { return sucess };
}

// Add the div automaticly to the end of the body element
$('body').append('<div class="position-fixed bottom-0 end-0 p-3" id="toast-container" style="z-index:9999"></div>');
// set constant to toast container
const b5toastContainerElement = document.getElementById("toast-container");

//don't touch code below if you don't know what are you doing
const b5toast = {
    tempo_de_espera_pre_definido: 4000,
    htmlToElement: function (html) {
        const template = document.createElement("template");
        html = html.trim();
        template.innerHTML = html;
        return template.content.firstChild;
    },
    mostrar: function (cor, mensagem, titulo, tempo_de_espera) {
        titulo = titulo ? titulo : "";
        const html = 
            `<div class="toast align-items-center mt-1 text-white bg-${cor} border-0" role="alert" aria-live="assertive" aria-atomic="true">
                <div class="d-flex">
                    <div class="toast-body">
                        <b>${titulo}</b>
                        <div>${mensagem}</div>
                    </div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                </div>
            </div>`;
        const toastElement = b5toast.htmlToElement(html);
        b5toastContainerElement.appendChild(toastElement);
        const toast = new bootstrap.Toast(toastElement, {
            delay : tempo_de_espera ? tempo_de_espera : b5toast.tempo_de_espera_pre_definido,
            animation: true
        });
        toast.show();
        setTimeout(() => toastElement.remove(), tempo_de_espera ? tempo_de_espera : b5toast.tempo_de_espera_pre_definido);
    },

    erro: function (mensagem, titulo, tempo_de_espera) {
        b5toast.mostrar("danger", mensagem, titulo, tempo_de_espera);
    },
    sucesso: function (mensagem, titulo, tempo_de_espera) {
        b5toast.mostrar("success", mensagem, titulo, tempo_de_espera);
    },
};