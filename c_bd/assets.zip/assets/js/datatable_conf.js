export const CONF_DATATABLE = {
    "language": {
        "url": '/static/c_bd/DataTables/pt-PT.json'
    },
    "processing": true,
    'serverSide': true,
    'serverMethod': 'post',
    "ajax" : {
        'url': '/devolve_registos'
    },
    // "fixedHeader": {
    //     header: true,
    // },
    scrollCollapse: true,
    scrollY: true,
    scrollX: true,
    "paging": true,

    // columnDefs: [
        // {
            // targets: '_all',
            // // className: 'dt-center',
            // render : 
            // DataTable.render.datetime('DD/MM/YYYY')
            // render: function (data, type, row) {
            //     //if (type === 'display') {
            //         return (isNaN(data) && moment(data).isValid()) ?
            //         moment(data).format('DD/MM/YYYY', 'llll')
            //         : data;
            //     //}
            //     //return data;
            // }
        // },
        // {
        //     targers: 0,
        //     visible: false
        // }
        // {
        //     targets: -1,
        //     width : 150
        // }
    // ],
    // columns: [
    //     { data: 'Código', visible:false, searchable:false },
    //     { data: 'Nome' },
    //     { data: 'Idade' },
    //     { data: 'NULL' },
    // ],
    // responsive: true,
    // dom: "<'row'<'col-sm-9'l><'col-sm-3'f>>" +
    // "<'row'<'col-sm-12'tr>>" +
    // "<'row'<'col-sm-12'p>>",    
    // "columns": {
    //     "url" : '/c_bd/devolve_campos_cabecalhos'
    // }

}
