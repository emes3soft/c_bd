function Ativar_Tooltips() {
    $("[data-bs-toggle='tooltip-botoes']").tooltip({
        containeer: 'body', 
        placement: 'top', html: true,
        delay: {"show": 500, "hide": 0},
    })
}