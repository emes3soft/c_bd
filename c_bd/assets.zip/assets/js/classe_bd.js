$(document).ready(function() {

    //b5toast.error("ERRO","Teste de erro",3000);
})