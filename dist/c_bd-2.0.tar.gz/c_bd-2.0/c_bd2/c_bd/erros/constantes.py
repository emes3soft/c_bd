PAGINA_WEB = """
    <div class="card w-100 bg-secondary">
        <div class="card-body">
            <h4 class="card-title text-bg-danger p-2 text-center">{} - {}</h4>
            <h5 class="card-text text-bg-light p-2 text-center">{}</h5>
            <div class="text-center">
                <a href="/" class="btn btn-info p-2"><i class="fa-solid fa-house"></i> Voltar à página inicial</a>
            </div>
        </div>
    </div>
"""