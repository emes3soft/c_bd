class REGISTOS_AFETADOS:
    total : int = 0
    por_tabela : list = []