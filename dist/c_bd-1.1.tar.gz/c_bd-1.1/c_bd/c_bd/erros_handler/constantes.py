PAGINA_WEB = """
    <!DOCTYPE html>
    <html lang="pt">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>ERROS</title>
    </head>
    <body>
        <b>Código do erro: </b>{}
        <b>Título do erro: </b>{}
        <b>Descrição do erro: </b>{}
    </body>
    </html>
"""