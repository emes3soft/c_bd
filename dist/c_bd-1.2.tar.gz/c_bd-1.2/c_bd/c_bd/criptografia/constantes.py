CHAVE = [
    b'2ecBhTPtPVPg8gz8',
    b'A3dT2cFcV6Zdko0U',
    b'NevVsNaIorcrZzOZ',
    b'9i7d9vri9GCc0Qec',
    b'8qppuuDRHxAhrzGJ',
    b'ejTvyeFjtwRspLbk',
    b'0FICIS0imbx63zmz',
    b'VVzuXxa8v6JIpPMJ',
    b'eBtjFQGIP7ifIXmT',
    b'l14X3dHXIDuzECu8',
]

FICHEIROS = {
    "base_dados": "bd.c_bd",
}